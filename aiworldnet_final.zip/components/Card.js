export default function Card({ item }) {
  return (
    <div className="bg-dark-800 rounded-lg overflow-hidden shadow-md">
      <img 
        src={item.image || 'https://source.unsplash.com/800x600/?artificial-intelligence'} 
        alt={item.title} 
        className="w-full h-48 object-cover" 
      />
      <div className="p-4">
        <h3 className="font-semibold text-lg text-white">{item.title}</h3>
        {item.description && <p className="text-gray-400 text-sm mt-2">{item.description}</p>}
      </div>
    </div>
  )
}
