import Link from 'next/link'

export default function Navbar() {
  return (
    <nav className="flex items-center justify-between p-4 bg-dark-900">
      <div className="flex items-center space-x-3">
        <img src="/logo.png" alt="AIWorldNet Logo" className="h-10 w-auto" />
        <span className="text-xl font-bold text-white">AIWorldNet</span>
      </div>
      <div className="space-x-4 text-gray-300">
        <Link href="/news">News</Link>
        <Link href="/blogs">Blogs</Link>
        <Link href="/jobs">Jobs</Link>
        <Link href="/products">Products</Link>
        <Link href="/resources">Resources</Link>
        <Link href="/startups">Startups</Link>
      </div>
    </nav>
  )
}
