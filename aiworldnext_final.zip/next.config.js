/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  trailingSlash: true,
  images: {
    unoptimized: true,
    domains: [
      'source.unsplash.com',
      'images.unsplash.com', 
      'via.placeholder.com',
      'ui-avatars.com',
      'logo.clearbit.com',
      'images-na.ssl-images-amazon.com'
    ]
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
}

module.exports = nextConfig